cat_line <- function(...) cat(..., "\n", sep = "")
