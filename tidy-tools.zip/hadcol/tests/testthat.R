library(testthat)
library(hadcol)

test_check("hadcol")
