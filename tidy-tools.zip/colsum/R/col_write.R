col_write <- function(df, path = tempdir()) {
}
