library(testthat)
library(colsum)

test_check("colsum")
